package com.example.q8;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Db extends SQLiteOpenHelper {
    public Db(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }


    public void addData(String name, int age, String address) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("age", age);
        cv.put("address",address);
        db.insert("emp", null, cv);
        db.close();
    }

    public boolean updateData(String id, String name, int age, String address) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", name);
        cv.put("age", age);
        cv.put("address", address);
        Cursor cursor = db.rawQuery("select * from emp where id = ?", new String[]{id});

        if (cursor.getCount() > 0) {
            int result = db.update("emp", cv, "id=?", new String[]{id});
            if (result == 1) {
                db.close();
                return true;
            }
        }
        db.close();
        return false;
    }

    public boolean removeData(String id) {

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from emp where id = ?", new String[]{id});

        if (cursor.getCount() > 0) {
            int result = db.delete("emp", "id=?", new String[]{id});
            if (result == 1) {
                db.close();
                return true;
            }
        }
        db.close();
        return false;
    }
    public Cursor fetchAllData() {
        SQLiteDatabase sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.rawQuery("select * from emp", null, null);
        return cursor;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}

