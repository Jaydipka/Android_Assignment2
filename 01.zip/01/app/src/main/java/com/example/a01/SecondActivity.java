package com.example.a01;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Second Activity");

        tv=findViewById(R.id.textView);

        Intent intent = getIntent();

        String name = intent.getStringExtra("Name");
        String age  = intent.getStringExtra("Age");
        String address = intent.getStringExtra("Address");
        String city = intent.getStringExtra("City");
        String phonenumber = intent.getStringExtra("Phonenumber");

        tv.setText("Name: "+name+"\nAge: "+age+ "\nAddress: "+address+" \nCity: "+city+" \nPhonenumber: "+phonenumber);

    }
}