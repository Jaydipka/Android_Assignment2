package com.example.q5;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Db obj = new Db(this, null, null,1);
    Button getDataBtn, insertBtn, updateBtn, removeBtn;
    EditText idTxt, nameTxt, ageTxt, addressTxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        updateBtn = findViewById(R.id.updateBtn);
        removeBtn = findViewById(R.id.removeBtn);
        getDataBtn = findViewById(R.id.getDataBtn);
        insertBtn = findViewById(R.id.insertBtn);
        ageTxt = findViewById(R.id.textBoxAge);
        addressTxt = findViewById(R.id.address);
        nameTxt = findViewById(R.id.textBoxName);
        idTxt = findViewById(R.id.textBoxId);
        
        


        insertBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                obj.addData(
                        nameTxt.getText().toString(),
                        Integer.parseInt(ageTxt.getText().toString()),
                        addressTxt.getText().toString()
                );
                Toast.makeText(MainActivity.this, "Record Inserted..", Toast.LENGTH_LONG).show();
            }
        });

        updateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                boolean result = obj.updateData(
                        idTxt.getText().toString(),
                        nameTxt.getText().toString(),
                        Integer.parseInt(ageTxt.getText().toString()),
                        addressTxt.getText().toString()
                );
                if (result){
                    Toast.makeText(MainActivity.this, "Updated SuccessFully", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(MainActivity.this, "Record Not Exists", Toast.LENGTH_SHORT).show();
                }

            }
        });

        removeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean result = obj.removeData(idTxt.getText().toString());
                if (result){
                    Toast.makeText(MainActivity.this, "Record Deleted SuccessFully", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this, "Record Not Exists", Toast.LENGTH_SHORT).show();
                }
            }
        });

        getDataBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getData();
            }
        });
    }

    private void getData() {
        StringBuffer buffer = new StringBuffer();
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        Cursor cursor = obj.fetchAllData();
        while (cursor.moveToNext()) {
            buffer.append("Id :" + cursor.getString(0) + "\n");
            buffer.append("Name :" + cursor.getString(1) + "\n");
            buffer.append("Age :" + cursor.getString(2) + "\n");
            buffer.append("Address :" + cursor.getString(3) + "\n");
            buffer.append("\n");
        }
        builder.setCancelable(true);
        builder.setTitle("Employee Records");
        builder.setMessage(buffer.toString());
        builder.show();


    }


}